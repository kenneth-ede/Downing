﻿namespace Downing.Models
{
    public class CompanyViewModel
    {
        public string? Name { get; set; }
        public string? Code { get; set; }
        public string? CurrentSharePrice { get; set; }
        public string? Created { get; set; }
    }
}
